package com.asykur.capstone1.presentation.fragment

import android.os.Bundle
import android.transition.TransitionInflater
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.navigation.fragment.findNavController
import com.asykur.capstone1.R
import com.asykur.core.data.source.remote.response.Movie
import com.asykur.capstone1.databinding.FragmentDetailMovieBinding
import com.asykur.capstone1.presentation.viewmodel.DetailMovieViewModel
import com.bumptech.glide.Glide
import org.koin.androidx.viewmodel.ext.android.viewModel


class DetailMovieFragment : Fragment() {

    private lateinit var binding: FragmentDetailMovieBinding
    private var movie: Movie? = null
    private val viewModel: DetailMovieViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            movie = it.getParcelable("movie")
        }
        val animation = TransitionInflater.from(requireContext()).inflateTransition(android.R.transition.move)
        sharedElementEnterTransition = animation
        sharedElementReturnTransition = animation
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDetailMovieBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.apply { 
            title = context.getString(R.string.detail_movie)
            navigationIcon = ContextCompat.getDrawable(requireContext(), com.asykur.core.R.drawable.ic_arrow_back)
            setNavigationOnClickListener { findNavController().popBackStack() }
        }
        
        movie?.let { movie ->
            Glide.with(requireActivity()).load("https://image.tmdb.org/t/p/w500/${movie.poster_path}").into(binding.ivDetailMovie)
            binding.tvOverview.text = movie.overview
            binding.tvRate.text = "${movie.vote_average} / 10"
            binding.tvTitle.text = movie.title

            var favoriteStatus = movie.isFavorite
            updateFavoriteButton(favoriteStatus)
            binding.btnFavorite.setOnClickListener {
                favoriteStatus = !favoriteStatus
                viewModel.setFavoriteMovie(movie, favoriteStatus)
                updateFavoriteButton(favoriteStatus)
            }
        }

    }

    private fun updateFavoriteButton(isFavorite: Boolean){
        if (isFavorite){
            binding.btnFavorite.setImageResource(R.drawable.ic_star)
        }else{
            binding.btnFavorite.setImageResource(R.drawable.ic_star_unselected)
        }
    }


}