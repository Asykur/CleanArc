package com.asykur.capstone1.presentation.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.asykur.capstone1.R
import com.asykur.capstone1.databinding.FragmentMainBinding
import com.asykur.capstone1.presentation.adapter.MovieAdapter
import com.asykur.capstone1.presentation.uistate.NowPlayingUiState
import com.asykur.capstone1.presentation.viewmodel.MainViewModel
import com.google.android.material.snackbar.Snackbar
import com.jakewharton.rxbinding2.widget.RxTextView
import org.koin.androidx.viewmodel.ext.android.viewModel

class MainFragment : Fragment() {

    private lateinit var binding: FragmentMainBinding
    private val viewModel: MainViewModel by viewModel()
    private val rvAdapter = MovieAdapter()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMainBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.ivFavorite.setOnClickListener {
            try {
                findNavController().navigate(R.id.favoriteGraph)
            } catch (e: Exception) {
                Snackbar.make(binding.root, "${e.message}", Snackbar.LENGTH_SHORT).show()
            }
        }

        RxTextView.textChanges(binding.etSearch)
            .skipInitialValue()
            .subscribe {
                rvAdapter.filter.filter(it.toString())
            }

        fetchMovie()
        initObserver()
    }

    private fun fetchMovie() {
        viewModel.getNowPlaying("94c18d256d5fbcee37e8d2ec7e028050", "en", 1)
    }

    private fun initObserver() {
        viewLifecycleOwner.lifecycleScope.launchWhenCreated {
            viewModel.nowPlayingUiState.collect { uiState ->
                when (uiState) {
                    is NowPlayingUiState.ShowLoading -> {
                        binding.pgMovie.visibility = View.VISIBLE
                        binding.svMovie.visibility = View.GONE
                    }
                    is NowPlayingUiState.ShowMovies -> {
                        binding.svMovie.visibility = View.VISIBLE
                        binding.pgMovie.visibility = View.GONE

                        if (uiState.movie != null) {
                            binding.rvNowPlaying.apply {
                                rvAdapter.setData(uiState.movie)
                                adapter = rvAdapter
                                layoutManager = GridLayoutManager(requireContext(), 2)

                                rvAdapter.onItemClicked = { ivMovie, movie ->
                                    val extras = FragmentNavigatorExtras(ivMovie to "imgDetail")
                                    findNavController().navigate(
                                        R.id.action_mainFragment_to_detailMovieFragment,
                                        bundleOf("movie" to movie),
                                        null,
                                        extras
                                    )
                                }
                            }

                        }
                    }
                    is NowPlayingUiState.ShowError -> {
                        binding.pgMovie.visibility = View.GONE
                        Snackbar.make(
                            binding.root,
                            uiState.errorMessage ?: "Unknown Error",
                            Snackbar.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }

    }
}