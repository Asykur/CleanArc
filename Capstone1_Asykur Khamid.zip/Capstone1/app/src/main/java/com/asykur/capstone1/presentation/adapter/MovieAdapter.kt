package com.asykur.capstone1.presentation.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.asykur.capstone1.databinding.ItemSimpleMovieBinding
import com.asykur.core.data.source.remote.response.Movie
import com.bumptech.glide.Glide

class MovieAdapter : RecyclerView.Adapter<MovieAdapter.VH>(), Filterable {
    private var filteredList = mutableListOf<Movie>()
    private var movieList = listOf<Movie>()

    var onItemClicked: ((View, Movie) -> Unit)? = null

    fun setData( newList: List<Movie>) {
        this.movieList = newList
        this.filteredList = newList.toMutableList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        return VH(
            ItemSimpleMovieBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.onBind(filteredList[position])
    }

    override fun getItemCount(): Int {
        return filteredList.size
    }

    inner class VH(private val itemBinding: ItemSimpleMovieBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        fun onBind(movie: Movie) {
            Glide.with(itemBinding.root)
                .load("https://image.tmdb.org/t/p/w500/${movie.poster_path}")
                .into(itemBinding.ivMovie)
            itemBinding.tvTitle.text = movie.title

            itemBinding.root.setOnClickListener {
                onItemClicked?.invoke(itemBinding.ivMovie, movie)
            }
        }

    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(char: CharSequence?): FilterResults {
                val query = char.toString()
                filteredList = if (query.isEmpty()) {
                    movieList.toMutableList()
                } else {
                    val filter = mutableListOf<Movie>()
                    filteredList
                        .filter {
                            it.title.lowercase().contains(query, true)
                        }.forEach { data ->
                            filter.add(data)
                        }
                    filter
                }
                return FilterResults().apply { values = filteredList }
            }

            override fun publishResults(char: CharSequence?, results: FilterResults?) {
                val resultData = results?.values as ArrayList<Movie>
                filteredList = if (resultData.size == 0) {
                    mutableListOf()
                } else {
                    resultData
                }
                notifyDataSetChanged()
            }

        }
    }
}